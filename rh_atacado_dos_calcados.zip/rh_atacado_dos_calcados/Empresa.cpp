#include <fstream>
#include "Empresa.hpp"

//Construtor vazio:
Empresa::Empresa(){
    faturamentoMensal = 0;
    nomeEmpresa = "Empresa";
    cnpj = "00000000000000";
}

//Construtor parametrizado:
Empresa::Empresa(float fm, std::string ne, std::string cn){
    faturamentoMensal = fm;
    nomeEmpresa = ne;
    cnpj = cn;
}

//Getters e Setters:
float Empresa::getFaturamentoMensal(){
    return faturamentoMensal;
}

void Empresa::setFaturamentoMensal(float fm){
    faturamentoMensal = fm;
}

std::string Empresa::getNomeEmpresa(){
    return nomeEmpresa;
}

void Empresa::setNomeEmpresa(std::string ne){
    nomeEmpresa = ne;
}

std::string Empresa::getCnpj(){
    return cnpj;
}

void Empresa::setCnpj(std::string cn){
    cnpj = cn;
}

//Getters do Dono e dos vetores:
Pessoa Empresa::getDono(){
    return dono;
}

std::vector<Asg> Empresa::getAsgs(){
    return asgs;
}

std::vector<Vendedor> Empresa::getVendedores(){
    return vendedores;
}

std::vector<Gerente> Empresa::getGerentes(){
    return gerentes;
}

//Outros metodos de Empresa:
void Empresa::carregarFuncoes(){
    try{
        std::ifstream arquivo("dados/funcoes.txt");
        if (!arquivo) {
            throw std::runtime_error("Erro ao abrir o arquivo.");
        } else {
            std::cout << "Encontrou o arquivo" << std::endl;
            std::string linha;
            while (std::getline(arquivo, linha)) {
                if (linha == "carregarEmpresa()") {
                    carregarEmpresa();
                } else if (linha == "carregarAsg()") {
                    carregarAsg();
                } else if (linha == "carregarVendedor()") {
                    carregarVendedor();
                } else if (linha == "carregarGerente()") {
                    carregarGerente();
                } else if (linha == "carregarDono()") {
                    carregarDono();
                } else if (linha == "imprimeAsgs()") {
                    imprimeAsgs();
                } else if (linha == "imprimeVendedores()") {
                    imprimeVendedores();
                } else if (linha == "imprimeGerentes()") {
                    imprimeGerentes();
                } else if (linha == "imprimeDono()") {
                    imprimeDono();
                } else if (linha == "buscaFuncionario()") {
                    std::cout << "FUNCAO NAO IMPLEMENTADA" << std::endl;
                } else if (linha == "calculaSalarioFuncionario()") {
                    std::cout << "FUNCAO NAO IMPLEMENTADA" << std::endl;
                } else if (linha == "calculaTodosOsSalarios()") {
                    calculaTodosOsSalarios();
                } else if (linha == "calcularRecisao()") {
                    std::cout << "FUNCAO NAO IMPLEMENTADA" << std::endl;
                } else {
                    std::cerr << "Função desconhecida: " << linha << std::endl;
                }
            }
        }

        arquivo.close();
    } catch(const std::exception& e){
        std::cerr << "Erro: " << e.what() << std::endl;
    }
    
}

void Empresa::carregarEmpresa(){
    std::vector<std::string> dadosEmpresa(3);
    int iterador = 0;

    //Leitura das linhas de empresa.txt:
    try{
        std::ifstream arquivo("dados/empresa.txt");
        if (!arquivo) {
            throw std::runtime_error("Erro ao abrir o arquivo.");
        } else {
            std::string linha;
            while (std::getline(arquivo, linha)) {
                char primeiroChar = linha[0];
                //Ignorando linhas com #:
                if(primeiroChar != '#'){
                    dadosEmpresa[iterador] = linha;
                    iterador++;
                } else {
                    continue;
                }
            }
        }

        arquivo.close();
    } catch(const std::exception& e){
        std::cerr << "Erro: " << e.what() << std::endl;
    }

    //Carregando os dados na empresa:
    setNomeEmpresa(dadosEmpresa[0]);
    setCnpj(dadosEmpresa[1]);
    setFaturamentoMensal(stof(dadosEmpresa[2]));

    std::cout << "Carregou empresa com sucesso." << std::endl;
}

void Empresa::carregarAsg(){
    std::vector<std::string> dadosAsg(20);
    int iterador = 0;

    //Leitura das linhas de empresa.txt:
    try{
        std::ifstream arquivo("dados/asg.txt");
        if (!arquivo) {
            throw std::runtime_error("Erro ao abrir o arquivo.");
        } else {
            std::string linha;
            while (std::getline(arquivo, linha)) {
                char primeiroChar = linha[0];
                //Ignorando linhas com # e *:
                if(primeiroChar != '#' && primeiroChar != '*'){
                    dadosAsg[iterador] = linha;
                    iterador++;
                    if(iterador == 20){
                        Asg a;
                        a.setNome(dadosAsg[1]);
                        a.setCpf(dadosAsg[2]);
                        a.setQtdFilhos(std::stoi(dadosAsg[3]));
                        a.setEstadoCivil(dadosAsg[4]);
                        
                        //definindo endereço pessoal:
                        Endereco ep;
                        ep.cidade = dadosAsg[5];
                        ep.cep = dadosAsg[6];
                        ep.bairro = dadosAsg[7];
                        ep.rua = dadosAsg[8];
                        ep.numero = std::stoi(dadosAsg[9]);

                        a.setEnderecoPessoal(ep);

                        //definindo data de nascimento:
                        Data dn;
                        dn.ano = std::stoi(dadosAsg[10]);
                        dn.mes = std::stoi(dadosAsg[11]);
                        dn.dia = std::stoi(dadosAsg[12]);

                        a.setDataNascimento(dn);

                        a.setMatricula(dadosAsg[13]);
                        a.setSalario(dadosAsg[14]);
                        a.setAdicionalInsalubridade(std::stof(dadosAsg[15]));
                        //calculando e atualizando salario:
                        a.setSalario(std::to_string(a.calcularSalario(std::stof(dadosAsg[16]))));

                        //definindo data de ingresso na empresa:
                        Data di;
                        di.ano = std::stoi(dadosAsg[17]);
                        di.mes = std::stoi(dadosAsg[18]);
                        di.dia = std::stoi(dadosAsg[19]);

                        a.setIngressoEmpresa(di);

                        //incrementando asg lido no vetor de asgs:
                        asgs.push_back(a);

                        iterador = 0;
                    }
                } else {
                    continue;
                }
            }
        }

        arquivo.close();
    } catch(const std::exception& e){
        std::cerr << "Erro: " << e.what() << std::endl;
    }

    std::cout << "Carregou ASG com sucesso." << std::endl;
}

void Empresa::carregarVendedor(){
    std::cout << "carregarVendedor" << std::endl;
}

void Empresa::carregarGerente(){
    std::cout << "carregarGerente" << std::endl;
}

void Empresa::carregarDono(){
    std::cout << "carregarDono" << std::endl;
}

void Empresa::imprimeAsgs(){
    std::cout << "imprimeAsgs" << std::endl;
}

void Empresa::imprimeVendedores(){
    std::cout << "imprimeVendedores" << std::endl;
}

void Empresa::imprimeGerentes(){
    std::cout << "imprimeGerentes" << std::endl;
}

void Empresa::imprimeDono(){
    std::cout << "imprimeDono" << std::endl;
}

void Empresa::buscaFuncionario(int matricula){
    std::cout << "buscaFuncionario" << std::endl;
}

void Empresa::calculaSalarioFuncionario(int matricula){
    std::cout << "calculaSalarioFuncionario" << std::endl;
}

void Empresa::calculaTodosOsSalarios(){
    std::cout << "calculaTodosOsSalarios" << std::endl;
}

void Empresa::calcularRecisao(int matricula, Data desligamento){
    std::cout << "calcularRecisao" << std::endl;
}